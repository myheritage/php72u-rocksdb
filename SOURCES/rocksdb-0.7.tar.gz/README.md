```
PHP 7 RocksDB extension

Build:

  phpize
  ./configure
  make
  make install

Debugging:
  # disable rocksdb in the ini file
  php -d 'extension=/path/to/rocksdb.so' test.php

Add extension to /etc/php.ini:

  extension=rocksdb.so

Notes:
  - Very basic support for get/put and column families
  - Exclusive use by transliteration for now

Development:
  # Kill puppet
  sudo puppet agent --disable
  sudo service puppet stop

  # Disable the preinstalled extension
  sudo vim /etc/php.d/40-rocksdb.ini

  sudo yum -y install rocksdb-devel

  # gcc >= 4.7
  sudo wget http://people.centos.org/tru/devtools-2/devtools-2.repo -O /etc/yum.repos.d/devtools-2.repo
  sudo yum -y install devtoolset-2-gcc devtoolset-2-binutils devtoolset-2-gcc-c++
  scl enable devtoolset-2 bash

  # PHP packages that work
  sudo yum -y remove php70u-cli php70u-common
  sudo yum -y install php70u-cli-7.0.5-1.MyHeritage.ius.el6.x86_64 php70u-common-7.0.5-1.MyHeritage.ius.el6.x86_64 php70u-devel

  # Run scripts by referring to the built extension
  php -d 'extension=/home/elad.efrat/devel/php7-rocksdb/modules/rocksdb.so' ~/t13n/T13nRocksDB.php
```

/*
 * Useful resources:
 *
 *   https://wiki.php.net/phpng-upgrading
 *   http://jpauli.github.io/2016/01/14/php-7-objects.html
 *   https://nikic.github.io/2015/06/19/Internal-value-representation-in-PHP-7-part-2.html
 *   https://github.com/facebook/rocksdb/blob/master/include/rocksdb/status.h
 */

#include <sys/stat.h>

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "php.h"
#include "php_ini.h"
#include "ext/standard/info.h"

#include <rocksdb/db.h>
#include <rocksdb/slice.h>
#include <rocksdb/options.h>

#include <syslog.h>

#ifndef	DEBUG
#define	DEBUG 0
#endif

using namespace rocksdb;

PHP_MINIT_FUNCTION(rocksdb);
PHP_MSHUTDOWN_FUNCTION(rocksdb);
PHP_MINFO_FUNCTION(rocksdb);

zend_object_handlers rocksdb_object_handlers;
typedef struct _rocksdb_object {
  char *dbPath;
  DB *db;
  std::vector<ColumnFamilyDescriptor> *cfDescriptors;
  std::vector<ColumnFamilyHandle*> *cfHandles;

  // This MUST be the last member
  zend_object std;
} rocksdb_object;

zend_class_entry *rocksdb_ce;

void rocksdb_free(rocksdb_object *obj)
{
#if DEBUG
  syslog(LOG_NOTICE, "rocksdb_free: enter");
#endif

  /*for (auto handle : *obj->cfHandles) {
    delete handle;
  }*/
  //efree(obj->cfHandles);
  //efree(obj->cfDescriptors);

  //delete obj->db;

  //efree(obj);

#if DEBUG
  syslog(LOG_NOTICE, "rocksdb_free: leave");
#endif
}

void
rocksdb_dtor_object(zend_object *object)
{
  rocksdb_object *obj = (rocksdb_object *)((char *)object - XtOffsetOf(rocksdb_object, std));

#if DEBUG
  syslog(LOG_NOTICE, "rocksdb_dtor_object: enter");
#endif

  zend_objects_destroy_object(object);

#if DEBUG
  syslog(LOG_NOTICE, "rocksdb_dtor_object: leave");
#endif
}

void
rocksdb_free_object(zend_object *zobj)
{
  rocksdb_object *obj = (rocksdb_object *)((char *)zobj - XtOffsetOf(rocksdb_object, std));

#if DEBUG
  syslog(LOG_NOTICE, "rocksdb_free_object: enter");
#endif

  rocksdb_free(obj);

  zend_object_std_dtor(zobj);

#if DEBUG
  syslog(LOG_NOTICE, "rocksdb_free_object: leave");
#endif
}

zend_object *
rocksdb_create_handler(zend_class_entry *ce)
{
  rocksdb_object *obj = (rocksdb_object *)ecalloc(1, sizeof(*obj) + zend_object_properties_size(ce));

#if DEBUG
  syslog(LOG_NOTICE, "rocksdb_create_handler: enter");
#endif

  obj->db = NULL;
  obj->cfDescriptors = (std::vector<ColumnFamilyDescriptor> *)ecalloc(1, sizeof(std::vector<ColumnFamilyDescriptor>));
  obj->cfHandles = (std::vector<ColumnFamilyHandle*> *)ecalloc(1, sizeof(std::vector<ColumnFamilyHandle*>));

  zend_object_std_init(&obj->std, ce);
  object_properties_init(&obj->std, ce);

  obj->std.handlers = &rocksdb_object_handlers;

#if DEBUG
  syslog(LOG_NOTICE, "rocksdb_create_handler: leave");
#endif

  return &obj->std;
}

PHP_METHOD(RocksDB, __construct)
{
  zend_object *zobj = Z_OBJ_P(getThis());
  rocksdb_object *obj = (rocksdb_object *)((char *)zobj - XtOffsetOf(rocksdb_object, std));

#if DEBUG
  syslog(LOG_NOTICE, "rocksdb::ctor: enter");
#endif
}

PHP_METHOD(RocksDB, Open)
{
  zend_object *zobj = Z_OBJ_P(getThis());
  rocksdb_object *obj = (rocksdb_object *)((char *)zobj - XtOffsetOf(rocksdb_object, std));

#if DEBUG
  syslog(LOG_NOTICE, "rocksdb::Open: enter");
#endif

  DBOptions options;
  options.IncreaseParallelism();
  options.create_if_missing = false;

  bool readOnly = false;
  HashTable *cf_hash = NULL;

  size_t len;
  zval *opts = NULL;
  if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "s|a", &obj->dbPath, &len, &opts) == FAILURE) {
    RETURN_NULL();
  }

  // Option parsing
  if (opts != NULL) {
    HashTable *opts_hash = Z_ARRVAL_P(opts);
    zend_string *opt_key;
    zval *opt_val;
    ZEND_HASH_FOREACH_STR_KEY_VAL(opts_hash, opt_key, opt_val) {
      if (zend_string_equals_literal(opt_key, "createIfMissing")) {
        options.create_if_missing = Z_TYPE_P(opt_val) == IS_TRUE ? true : false;
      } else if (zend_string_equals_literal(opt_key, "columnFamilies")) {
        if (opt_val != NULL) {
          cf_hash = Z_ARRVAL_P(opt_val);

          zval *zv;
          ZEND_HASH_FOREACH_VAL(cf_hash, zv) {
            char *cfName = estrdup(Z_STRVAL_P(zv));
            obj->cfDescriptors->push_back(ColumnFamilyDescriptor(cfName, ColumnFamilyOptions()));
          } ZEND_HASH_FOREACH_END();
        }
      } else if (zend_string_equals_literal(opt_key, "readOnly")) {
        readOnly = Z_TYPE_P(opt_val) == IS_TRUE ? true : false;
      }
    } ZEND_HASH_FOREACH_END();
  }

  // Add the default column family if needed.
  if (cf_hash == NULL) {
    obj->cfDescriptors->push_back(ColumnFamilyDescriptor(kDefaultColumnFamilyName, ColumnFamilyOptions()));
  }

  // See https://github.com/facebook/rocksdb/blob/master/include/rocksdb/status.h
  Status s;

  // There's a special case of creating a new database with column families. This is ugly,
  // but the simplest way to achieve it in a maintainable way.
  if (options.create_if_missing && cf_hash != NULL) {
    struct stat sb;
    int exists = stat(obj->dbPath, &sb) == 0;
    if (!exists) {
      // Open the database.
      Options tmp_options;
      tmp_options.create_if_missing = true;
      s = DB::Open(tmp_options, obj->dbPath, &obj->db);
      if (!s.ok()) {
        RETURN_LONG(s.code());
      }

      // Create column families.
      zval *zv;
      ZEND_HASH_FOREACH_VAL(cf_hash, zv) {
        // Never create the default column family.
        if (kDefaultColumnFamilyName.compare(Z_STRVAL_P(zv)) == 0) {
          continue;
        }

        ColumnFamilyHandle* cf;
        s = obj->db->CreateColumnFamily(ColumnFamilyOptions(), Z_STRVAL_P(zv), &cf);
        if (!s.ok()) {
          RETURN_LONG(s.code());
        }
        delete cf;
      } ZEND_HASH_FOREACH_END();

      // Close the database
      delete obj->db;
    }
  }

  if (readOnly) {
    s = DB::OpenForReadOnly(options, obj->dbPath, *obj->cfDescriptors, obj->cfHandles, &obj->db);
  } else {
    s = DB::Open(options, obj->dbPath, *obj->cfDescriptors, obj->cfHandles, &obj->db);
  }

#if DEBUG
  syslog(LOG_NOTICE, "ROCKSDB: Open: dbPath=%s code=%d subcode=%d", obj->dbPath, s.code(), s.subcode());
#endif

  RETURN_LONG(s.code());
}

PHP_METHOD(RocksDB, Put)
{
  zend_object *zobj = Z_OBJ_P(getThis());
  rocksdb_object *obj = (rocksdb_object *)((char *)zobj - XtOffsetOf(rocksdb_object, std));

  zend_string *key;
  zend_string *value;
  zend_string *cfName = NULL;
  if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "SS|S", &key, &value, &cfName) == FAILURE) {
    RETURN_NULL();
  }

  if (cfName != NULL) {
    int i = 0;
    ColumnFamilyHandle *cfHandle;
    for (auto cfDescriptor : *obj->cfDescriptors) {
      if (cfDescriptor.name.compare(ZSTR_VAL(cfName)) == 0) {
        cfHandle = obj->cfHandles->at(i);
        break;
      }

      i++;
    }

    if (cfHandle == NULL) {
      RETURN_NULL();
    }

    obj->db->Put(WriteOptions(), cfHandle, ZSTR_VAL(key), ZSTR_VAL(value));
  } else {
    obj->db->Put(WriteOptions(), ZSTR_VAL(key), ZSTR_VAL(value));
  }
}

PHP_METHOD(RocksDB, Get)
{
  zend_object *zobj = Z_OBJ_P(getThis());
  rocksdb_object *obj = (rocksdb_object *)((char *)zobj - XtOffsetOf(rocksdb_object, std));

  zend_string *key;
  zend_string *cfName = NULL;
  if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "S|S", &key, &cfName) == FAILURE) {
    RETURN_NULL();
  }

#if DEBUG
  syslog(LOG_NOTICE, "ROCKSDB: Get: key=%s cfName=%s", ZSTR_VAL(key), ZSTR_VAL(cfName));
#endif

  std::string value;

  if (cfName != NULL) {
    int i = 0;
    ColumnFamilyHandle *cfHandle;
    for (auto cfDescriptor : *obj->cfDescriptors) {
      if (cfDescriptor.name.compare(ZSTR_VAL(cfName)) == 0) {
        cfHandle = obj->cfHandles->at(i);
        break;
      }

      i++;
    }

    obj->db->Get(ReadOptions(), cfHandle, ZSTR_VAL(key), &value);
  } else {
    obj->db->Get(ReadOptions(), ZSTR_VAL(key), &value);
  }

  RETURN_STRING(value.c_str());
}

PHP_METHOD(RocksDB, Delete)
{
  zend_object *zobj = Z_OBJ_P(getThis());
  rocksdb_object *obj = (rocksdb_object *)((char *)zobj - XtOffsetOf(rocksdb_object, std));

  zend_string *key;
  zend_string *cfName = NULL;
  if (zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "S|S", &key, &cfName) == FAILURE) {
    RETURN_NULL();
  }

  if (cfName != NULL) {
    int i = 0;
    ColumnFamilyHandle *cfHandle;
    for (auto cfDescriptor : *obj->cfDescriptors) {
      if (cfDescriptor.name.compare(ZSTR_VAL(cfName)) == 0) {
        cfHandle = obj->cfHandles->at(i);
        break;
      }

      i++;
    }

    obj->db->Delete(WriteOptions(), cfHandle, ZSTR_VAL(key));
  } else {
    obj->db->Delete(WriteOptions(), ZSTR_VAL(key));
  }
}

PHP_METHOD(RocksDB, Close)
{
  zend_object *zobj = Z_OBJ_P(getThis());
  rocksdb_object *obj = (rocksdb_object *)((char *)zobj - XtOffsetOf(rocksdb_object, std));

  rocksdb_free(obj);
}

PHP_METHOD(RocksDB, getDbPath)
{
  zend_object *zobj = Z_OBJ_P(getThis());
  rocksdb_object *obj = (rocksdb_object *)((char *)zobj - XtOffsetOf(rocksdb_object, std));

  RETURN_STRING(obj->dbPath);
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_rocksdb_put, 0, 0, 2)
  ZEND_ARG_INFO(0, key)
  ZEND_ARG_INFO(0, value)
ZEND_END_ARG_INFO()

zend_function_entry rocksdb_methods[] = {
  PHP_ME(RocksDB, __construct, NULL, ZEND_ACC_PUBLIC | ZEND_ACC_CTOR)
  PHP_ME(RocksDB, Open, NULL, ZEND_ACC_PUBLIC)
  PHP_ME(RocksDB, Close, NULL, ZEND_ACC_PUBLIC)
  PHP_ME(RocksDB, Put, arginfo_rocksdb_put, ZEND_ACC_PUBLIC)
  PHP_ME(RocksDB, Get, NULL, ZEND_ACC_PUBLIC)
  PHP_ME(RocksDB, Delete, NULL, ZEND_ACC_PUBLIC)
  PHP_ME(RocksDB, getDbPath, NULL, ZEND_ACC_PUBLIC)
  { NULL, NULL, NULL }
};

zend_module_entry rocksdb_module_entry = {
#if ZEND_MODULE_API_NO >= 20010901
  STANDARD_MODULE_HEADER,
#endif
  "rocksdb",
  NULL,
  PHP_MINIT(rocksdb),
  PHP_MSHUTDOWN(rocksdb),
  NULL,
  NULL,
  PHP_MINFO(rocksdb),
#if ZEND_MODULE_API_NO >= 20010901
  "1.0",
#endif
  STANDARD_MODULE_PROPERTIES
};

#ifdef COMPILE_DL_ROCKSDB
ZEND_GET_MODULE(rocksdb)
#endif

PHP_MINIT_FUNCTION(rocksdb)
{
  zend_class_entry ce;

  INIT_CLASS_ENTRY(ce, "RocksDB", rocksdb_methods);
  rocksdb_ce = zend_register_internal_class(&ce);

  rocksdb_ce->create_object = rocksdb_create_handler;

  memcpy(&rocksdb_object_handlers, zend_get_std_object_handlers(), sizeof(rocksdb_object_handlers));

  rocksdb_object_handlers.free_obj = rocksdb_free_object;
  rocksdb_object_handlers.dtor_obj = rocksdb_dtor_object;
  rocksdb_object_handlers.clone_obj = NULL;

  rocksdb_object_handlers.offset = XtOffsetOf(rocksdb_object, std);

  return SUCCESS;
}

PHP_MSHUTDOWN_FUNCTION(rocksdb)
{
  return SUCCESS;
}

PHP_MINFO_FUNCTION(rocksdb)
{
  php_info_print_table_start();
  php_info_print_table_header(2, "rocksdb support", "enabled");
  php_info_print_table_end();
}
